import React, { useEffect } from 'react';
const Pagination = (props) => {
    useEffect(() => {
    }, [props])
    let { pagesCount, onchange, currentActivePage } = props;
    let pagination = []
    for (let i = 0; i < pagesCount; i++) {
        pagination.push(<p className={(i + 1) === currentActivePage ? 'active' : ''} id={`page${i + 1}`} key={`page${i + 1}`} onClick={() => onchange(i + 1)}>{i + 1}</p>)
    }
    return <div className="pagination">
        <p onClick={() => currentActivePage !== 1 && onchange(currentActivePage - 1)}>&laquo;</p>
        {pagination}
        <p onClick={() => currentActivePage !== pagesCount && onchange(currentActivePage + 1)}>&raquo;</p>
    </div>
}
export default Pagination;
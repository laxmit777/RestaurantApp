import React, { useEffect, useState } from 'react';
import TableComponent from './table'
import Pagination from './pagination'
import { ALL } from './constants';
const App = () => {
  const url = "http://localhost:8010/restaurants";
  const [data, setData] = useState({
    columns: ['Name', 'City', 'State', 'Phone Number', 'Genres'],
    rows: []
  });
  const [tableData, setTableData] = useState(data)
  const [selectedState, setselectedState] = useState('')
  const [selectedGenre, setSelectedGenre] = useState('')
  const [searchValue, setSearchValue] = useState('')
  const [totalPagesCount, setTotalPagesCount] = useState(0)
  const [currentActivePage, setCurrentActivePage] = useState(1)
  const stateList = [];
  const GenresList = [];
  const LIMIT = 10;
  useEffect(() => {
    let searchInput = document.getElementById("searchInput");
    searchInput.addEventListener("keydown", function (e) {
      if (e.key === 'Enter') {  //checks whether the pressed key is "Enter"
        document.getElementById('btnSearch').click()
      }
    });
    getData()
  }, [])
  useEffect(() => {
    let pagesCount;
    if ((selectedState === "" || selectedState === ALL) && (selectedGenre === "" || selectedGenre === ALL) && searchValue === "") {
      pagesCount = Math.ceil(data.rows.length / LIMIT)
      setTotalPagesCount(pagesCount)
    } else {
      pagesCount = Math.ceil(tableData.rows.length / LIMIT)
      setTotalPagesCount(pagesCount)
    }
  }, [tableData])
  const getData = () => {
    var req = new Request(url, {
      method: "GET"
    })
    fetch(req)
    .then(res=>res.json())
    .then(response=>{
      let restaurants = [];
      response.map(restaurant => {
        let restObj = {};
        restObj.Name = restaurant.name;
        restObj.City = restaurant.city;
        restObj.State = restaurant.state;
        restObj['Phone Number'] = restaurant.phoneNumber;
        restObj.Genres = restaurant.genres;
        restaurants.push(restObj);
      });
      setData({...data, rows:restaurants});
      let rows = restaurants.slice((currentActivePage - 1) * LIMIT, currentActivePage * LIMIT);
      setTableData({ ...tableData, rows: rows })
    })
  }
  const onchange = (page) => {
    document.getElementById(`page${currentActivePage}`).className = ''
    setCurrentActivePage(page);
    document.getElementById(`page${page}`).className = 'active'
    let rows;
    if ((selectedState === "" || selectedState === ALL) && (selectedGenre === "" || selectedGenre === ALL) && searchValue === "") {
      rows = data.rows.slice((page - 1) * LIMIT, page * LIMIT)
    } else {
      rows = tableData.rows.slice((page - 1) * LIMIT, page * LIMIT)
    }
    setTableData({ ...tableData, rows: rows })
  }
  data.rows.map(item => {
    if (!stateList.includes(item.State)) stateList.push(item.State)
    item.Genres.map(genre => {
      if (!GenresList.includes(genre)) GenresList.push(genre)
    });
    return true
  })
  const onStateSelect = (state) => {
    let filteredData = []
    setselectedState(state)
    if (state === ALL && (selectedGenre === "" || selectedGenre === ALL)) {
      filteredData = data.rows
    } else if (state === ALL) {
      data.rows.map(item => {
        if (selectedGenre !== "") {
          if (item.Genres === selectedGenre) return filteredData.push(item)
        }
        return false
      })
    } else {
      data.rows.map(item => {
        if (selectedGenre !== "" && selectedGenre !== ALL) {
          if (item.State === state && item.Genres === selectedGenre) return filteredData.push(item)
          return false
        }
        else if (item.State === state) return filteredData.push(item)
        else return false
      })
    }
    setTableData({ ...tableData, rows: filteredData })
  }
  const onGenreSelect = (genre) => {
    let filteredData = [];
    setSelectedGenre(genre)
    if (genre === ALL && (selectedState === "" || selectedState === ALL)) {
      filteredData = data.rows
    } else if (genre === ALL) {
      data.rows.map(item => {
        if (selectedState !== "") {
          if (item.State === selectedState) return filteredData.push(item)
        }
        return false
      })
    }
    else {
      data.rows.map(item => {
        if (selectedState !== "" && selectedState !== ALL) {
          if (item.Genres.includes(genre) && item.State === selectedState) return filteredData.push(item)
          return false
        }
        else if (item.Genres.includes(genre)) return filteredData.push(item)
        else return false
      })
    }
    setTableData({ ...tableData, rows: filteredData })
  }
  const onSearch = (value) => {
    setSearchValue(value)
    if (value === "") setTableData({ ...tableData, rows: data.rows.slice((currentActivePage - 1) * LIMIT, currentActivePage * LIMIT) })
  }
  const getsearchData = () => {
    let searchData = [];
    if (searchValue.trim() !== "") {
      tableData.rows.map(item => {
        if (item.Name === searchValue || item.City === searchValue || item.Genres === searchValue) return searchData.push(item)
        return false
      })
    } else {
      searchData = data.rows.slice((currentActivePage - 1) * LIMIT, currentActivePage * LIMIT)
    }
    setTableData({ ...tableData, rows: searchData })
  }
  
  return (
    <div className="App">
      <header>Restaurant</header>
      <div className='filter-options'>
        <label>State:</label>
        <select onChange={(e) => onStateSelect(e.target.value)}>
          <option key={ALL} value={ALL}>All</option>
          {stateList.map((state, i) => <option key={state + i} value={state}>{state}</option>)}
        </select>
        <label>Genre:</label>
        <select onChange={(e) => onGenreSelect(e.target.value)}>
          <option key={ALL} value={ALL}>All</option>
          {GenresList.map((genre, i) => <option key={genre + i} value={genre}>{genre}</option>)}
        </select>
        <input type="text" placeholder="Search" id='searchInput' onChange={(e) => onSearch(e.target.value)} />
        <button className='search-button' id="btnSearch" onClick={() => getsearchData()}>Search</button>
      </div>
      <TableComponent data={tableData} />
      <Pagination pagesCount={totalPagesCount} currentActivePage={currentActivePage} onchange={onchange} />
    </div>
  );
}

export default App;

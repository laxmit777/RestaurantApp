import React, { useEffect } from 'react';
import './App.css';

const TableComponent = (props) => {
    useEffect(() => {

    }, [props])
    // Data
    var dataColumns = props.data.columns;
    var dataRows = props.data.rows;
    dataRows = dataRows.sort((a, b) => a.Name !== b.Name ? a.Name < b.Name ? -1 : 1 : 0);
    var tableHeaders = (<thead>
        <tr>
            {dataColumns.map((column) => {
                return <th key={column}>{column}</th>;
            })}
        </tr>
    </thead>);

    var tableBody = dataRows.map((row, i) => {
        return (
            <tr key={i}>
                {dataColumns.map((column, j) => {
                    if (column === 'Genres')
                        return <td key={j}>{row[column].join(',')}</td>;
                    return <td key={j}>{row[column]}</td>;
                })}
            </tr>);
    });

    // Decorate with Bootstrap CSS
    return (<div><table className="table" cellSpacing="0" width="100%">
        {tableHeaders}
        {tableBody.length ? <tbody>
            {tableBody}
        </tbody> : null}
    </table>
        {!tableBody.length ? <div className='no-data-message'>No Data</div> : null}
    </div>)
}
export default TableComponent;